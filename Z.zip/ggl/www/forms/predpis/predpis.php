<div id="predpis_tab" ><script>view("predpis");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_predpis" value="&#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1086;&#1077; &#1087;&#1088;&#1077;&#1076;&#1087;&#1080;&#1089;&#1072;&#1085;&#1080;&#1077; " onclick="f_predpis_create()"  />
</form>
<div id="tab_predpis_view"></div>
</div>
<div id="add_predpis_div"  style="display:none">
  <? include("create_predpis.php"); ?>
</div>
