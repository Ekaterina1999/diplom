<div id="zadan_tab" ><script>view("zadan");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_zadan" value="&#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1086;&#1077; &#1079;&#1072;&#1076;&#1072;&#1085;&#1080;&#1077;" onclick="f_zadan_create()"  />

</form>
<div id="tab_zadan_view"></div>
</div>
<div id="add_zadan_div"  style="display:none">
  <? include("create_zadan.php"); ?>
</div>
