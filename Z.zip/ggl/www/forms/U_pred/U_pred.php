<div id="U_pred_tab" ><script>view("U_pred");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_U_pred" value="  &#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1086;&#1077; &#1091;&#1074;&#1077;&#1076;&#1086;&#1084;&#1083;&#1077;&#1085;&#1080;&#1077;" onclick="f_U_pred_create()"  />
</form>
<div id="tab_U_pred_view"></div>
</div>
<div id="add_U_pred_div"  style="display:none">
  <? include("create_U_pred.php"); ?>
</div>
