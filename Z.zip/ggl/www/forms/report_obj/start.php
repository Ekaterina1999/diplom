<?


 include_once("..\link\link.php");
 $list=$_POST['list'];
 $d1=$_POST['d1'];
 $d2=$_POST['d2'];
 
if ($list=="0"){
include('start0.php');}else
{include('start1.php');
}

?>