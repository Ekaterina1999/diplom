<div id="act_tab" ><script>view("act");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_act" value="������� ����� ���" onclick="f_act_create()"  />
</form>
<div id="tab_act_view"></div>
</div>
<div id="add_act_div"  style="display:none">
  <? include("create_act.php"); ?>
</div>
