<?php 
function list_incoming($op) {
include_once("..\..\link\link.php");
	
			 $q_incom=mysql_query ('SELECT incoming.num_incoming, incoming.incoming_date, incoming.id FROM incoming order where incoming.id="'.$id_incoming.'" by incoming.incoming_date, incoming.num_incoming');
				if (mysql_error()){echo"  <p>�� �� ������ �� ������ ��������� </p>";}
				else{
				while ($r_incom = mysql_fetch_row($q_incom)) 
					{ if ($r_incom[0] == ""){		echo"  <p>�� �� ������ �� ������ ��������� </p>";}
						else{echo'<p><input  type="checkbox" data_id= "'.$r_incom[2].'" name="selected_in_'.$r_incom[2].'" />'.$r_incom[0].' �� '.$r_incom[1].'</p>';
								$op=$op.'<p><input  type="checkbox" data_id= "'.$r_incom[2].'" name="selected_in_'.$r_incom[2].'" />'.$r_incom[0].' �� '.$r_incom[1].'</p>';
							}
					}}
}

function list_type_violation($op1) {
	$op1='<select name="t_v" onchange="list_name_obj_violation($op2)">';
	$op1=$op1.'<option value="0"> --�������� ��� ���������-- </option>';
			include_once("..\..\link\link.php");
			
				 $q_incom=mysql_query ("SELECT name_type, Id_type_violation FROM type_violation ");
					while ($r_incom = mysql_fetch_row($q_incom)) 
						{ if ($r_incom[0] == ""){}
							else{
							//echo '<option value="'.$r_incom[1].'"> '.$r_incom[0].'</option>';
									$op1=$op1.'<option value="'.$r_incom[1].'"> '.$r_incom[0].'</option>';
								}
						}
						$op1=$op1.'</select>';
						echo $op1;
	}
	
function list_name_obj_violation($op2) {
	if ($_POST[$t_v]=1){
	$op2='<select name="n_o_v" onchange="">';
	include_once("..\link\link.php");
			
				 $q_incom=mysql_query ("SELECT name_type, Id_type_violation FROM type_violation ");
					while ($r_incom = mysql_fetch_row($q_incom)) 
						{ if ($r_incom[0] == ""){}
							else{
							//echo '<option value="'.$r_incom[1].'"> '.$r_incom[0].'</option>';
									$op2=$op2.'<option value="'.$r_incom[1].'"> '.$r_incom[0].'</option>';
								}
						}
						$op2=$op2.'</select>';
						echo $op2;}
	}


function list_obj($op3) {
	$op3='<select name="l_obj" onchange="list_name_obj_violation($op2)">';
	$op3=$op3.'<option value="0"> --�������� ������--  </option>';
			include_once("..\..\link\link.php");
				 $q_obj=mysql_query ("SELECT Name_org, id FROM complaints_obj ");
					while ($r_obj = mysql_fetch_row($q_obj)) 
						{ if ($r_obj[0] == ""){}
							else{
							//echo '<option value="'.$r_incom[1].'"> '.$r_incom[0].'</option>';
									$op3=$op3.'<option value="'.$r_obj[1].'"> '.$r_obj[0].'</option>';
								}
						}
						$op3=$op3.'</select>';
						echo $op3;
	}

function list_city($s_city) {
	$s_city='<select name="l_city" >';
	$s_city=$s_city.'<option value="0"> --�������� ����� --  </option>';
		include_once("..\..\link\link.php");
				 $q_city=mysql_query ("SELECT name, id FROM city_zab order by kod ");
					while ($r_city = mysql_fetch_row($q_city)) 
						{ if ($r_city[0] == ""){}
							else{
							//echo '<option value="'.$r_incom[1].'"> '.$r_incom[0].'</option>';
									$s_city=$s_city.'<option value="'.$r_city[1].'"> '.$r_city[0].'</option>';
								}
						}
						$s_city=$s_city.'</select>';
						echo $s_city;
	}
	?>