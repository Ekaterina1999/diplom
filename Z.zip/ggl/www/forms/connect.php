<?php
global $db;
include_once("link\link.php");

?>
