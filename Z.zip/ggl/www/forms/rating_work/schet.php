<?php 
function schet_rw($user_id, $date_rmw1, $date_rmw2, $sel_rmw){
 $p_rw='<td>'.$user_id.'</td>';
return $p_rw;

}

?>
