<?php
$db = mysql_connect("localhost", "root", "");
mysql_query("set NAMES utf8");
mysql_select_db("housing_supervision1", $db); 

?>
