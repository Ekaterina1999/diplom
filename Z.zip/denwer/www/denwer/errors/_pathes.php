<table border=0 cellpadding=3 cellcpacing=1>
<tr bgcolor=silver>
	<td><b>URL</td>
	<td><b>���� ���������</td>
</tr>
<tr bgcolor=#EEEEEE>
	<td nowrap><tt>http://***/cgi-glob/script.cgi</td>
	<td nowrap><tt>/home/cgi-glob/script.cgi</td>
</tr>
<tr bgcolor=#EEEEEE>
	<td nowrap><tt>http://***/cgi/script.cgi</td>
	<td nowrap><tt>/home/***/cgi/script.cgi</td>
</tr>
<tr bgcolor=#EEEEEE>
	<td nowrap><tt>http://***/cgi-bin/script.cgi</td>
	<td nowrap><tt>/home/***/cgi-bin/script.cgi</td>
</tr>
</table>
<p>