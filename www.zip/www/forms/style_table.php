<style>
.td_style_1{
white-space: normal;
	height:100; 
	width:10; 
	align:center;
}
.td_style_2{
    white-space: normal;  
	height:100; 
	width:20; 
	align:center;
}
.td_style_3{
    white-space: normal;  
	height:100; 
	width:30;
	align:center; 
}
.td_style_4{
    white-space: normal;  
	height:100; 
	width:40; 
	align:center;
}
.td_style_5{
	white-space: normal;
	height:100; 
	width:40; 
	align:center;
}
.td_style_6{
    white-space: normal;
	height:100; 
	width:10; 
	align:center;
}
.td_style_7{
    white-space: normal;  
	height:100; 
	width:40; 
	align:center;
}
.td_style_8{
    white-space: normal;  
	height:100; 
	width:50;
	align:center; 
}
.td_style_9{
    white-space: normal;  
	height:100; 
	width:30;
	align:center; 
}
</style>