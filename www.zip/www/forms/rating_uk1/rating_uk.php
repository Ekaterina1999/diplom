<p align="center"><b>
  
&#1056;&#1077;&#1081;&#1090;&#1080;&#1085;&#1075; &#1059;&#1050;</b></p>
<p align>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>
<p align>&#1057;
  <input id="d_1" type="date"  value="<? $d=date_create();
		echo $d->format('Y-m-d');
		?>" />
</p>
<p align=>&#1055;&#1086;
  <input id="d_2" type="date"  value="<? $d=date_create();
		echo $d->format('Y-m-d');
		?>" />
</p>
<p align=>
  <input type="button" name="start" value="&#1057;&#1092;&#1086;&#1088;&#1084;&#1080;&#1088;&#1086;&#1074;&#1072;&#1090;&#1100; &#1088;&#1077;&#1081;&#1090;&#1080;&#1085;&#1075; " onclick="rating_uk_f()" />
</p>
<div id="view_rating"  style="display:block">
 </div>

