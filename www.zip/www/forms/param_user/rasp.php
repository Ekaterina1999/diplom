<div id="rasp_tab" >
<script>view("rasp");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_rasp" value="&#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1086;&#1077; &#1088;&#1072;&#1089;&#1087;&#1086;&#1088;&#1103;&#1078;&#1077;&#1085;&#1080;&#1077;" onclick="f_rasp_create()"  />
</form>
<div id="tab_rasp_view"></div>
</div>
<div id="add_rasp_div"  style="display:none">
  <? include("create_rasp.php"); ?>
</div>