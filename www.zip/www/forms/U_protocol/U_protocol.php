<div id="U_protocol_tab" ><script>view("U_protocol");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_U_protocol" value="  &#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1086;&#1077; &#1091;&#1074;&#1077;&#1076;&#1086;&#1084;&#1083;&#1077;&#1085;&#1080;&#1077; &#1085;&#1072; &#1087;&#1088;&#1086;&#1090;&#1086;&#1082;&#1086;&#1083;  " onclick="f_U_protocol_create()"  />
</form>
<div id="tab_U_protocol_view"></div>
</div>
<!-- +++++++++ -->
<div id="view_U_protocol_div"  style="display:none">
 </div>
 <!--  -->
<div id="add_U_protocol_div"  style="display:none">
  <? include("create_U_protocol.php"); ?>
</div>
