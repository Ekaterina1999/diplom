<? 
//добавила весь код
include_once("..\link\link.php");

$path=$_POST['path'];
$id=$_POST['id'];

$b_b= '<input  type="button" height="50" align="center" class="back_form" value="&#1053;&#1072;&#1079;&#1072;&#1076;" onclick="divindiv('."'".$path.'_tab'."'".')" />';
$b_u= '<input  type="button" height="50" align="center" class="up_form" value="&#1056;&#1077;&#1076;&#1072;&#1082;&#1090;&#1080;&#1088;&#1086;&#1074;&#1072;&#1090;&#1100;" onclick="butt_up('."'".$path."'".''.",$(this).val(),"."'".$id."'".')" />';
 
 echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';



$year=date('Y');

$text_q='SELECT   `notify_protocol`.`id` ,  `notify_protocol`.`num` ,  `date_notify` , `date_plan_protocol`, `time_plan_protool` ,`act`.`num`, `act`.`date_act`,  `FIO` 
FROM  `notify_protocol`
left join `act` on `act`.id=`notify_protocol`.id_act 
left join `link_u_protocol_workers` on `link_u_protocol_workers`.id_u_protocol=`notify_protocol`.id
left join `workers` on `workers`.id=`link_u_protocol_workers`.id_user
  where  `year_u_protocol` ="'.$year.'" and `notify_protocol`.`id` ="'.$id.'"  ORDER BY `notify_protocol`.`num` DESC ';
  
  $q=mysql_query ($text_q)or die (Mysql_error());
  $count=mysql_num_rows($q);
  while ($r = mysql_fetch_row($q))
   {
 
   $p=$p.'<p>  &#1059;&#1074;&#1077;&#1076;&#1086;&#1084;&#1083;&#1077;&#1085;&#1080;&#1077; &#1085;&#1072; &#1087;&#1088;&#1086;&#1090;&#1086;&#1082;&#1086;&#1083; &#8470; '.$r[1].' &#1086;&#1090; '.date('d.m.Y',strtotime($r[2])).'</p>
   <p> &#1052;&#1077;&#1088;&#1086;&#1087;&#1088;&#1080;&#1103;&#1090;&#1080;&#1077; &#1079;&#1072;&#1087;&#1083;&#1072;&#1085;&#1080;&#1088;&#1086;&#1074;&#1072;&#1085;&#1086; &#1085;&#1072;: '.iconv("utf-8","windows-1251",$r[3]).' '.iconv("utf-8","windows-1251",$r[4]).'</p>
   <p>&#1054;&#1089;&#1085;&#1086;&#1074;&#1072;&#1085;&#1086; &#1085;&#1072; &#1072;&#1082;&#1090;&#1077; &#8470; : '.iconv("utf-8","windows-1251",$r[5]).' &#1086;&#1090; '.date('d.m.Y',strtotime($r[6])).'</p>
   <p> &#1048;&#1085;&#1089;&#1087;&#1077;&#1082;&#1090;&#1086;&#1088; : '.iconv("utf-8","windows-1251",$r[7]).'</p>';
   $up=$up.'<p>&#1059;&#1074;&#1077;&#1076;&#1086;&#1084;&#1083;&#1077;&#1085;&#1080;&#1077; &#1085;&#1072; &#1087;&#1088;&#1086;&#1090;&#1086;&#1082;&#1086;&#1083; &#8470; '.$r[1].' &#1086;&#1090; <input type="date" class="data_up" id="d1" value="'.$r[2].'"/></p>
   <p>&#1052;&#1077;&#1088;&#1086;&#1087;&#1088;&#1080;&#1103;&#1090;&#1080;&#1077; &#1079;&#1072;&#1087;&#1083;&#1072;&#1085;&#1080;&#1088;&#1086;&#1074;&#1072;&#1085;&#1086; &#1085;&#1072; <input type="date" class="data_up" id="d2" value="'.$r[3].'"/>  <input type="time" class="data_up" id="d3" value="'.$r[4].'"/></p>
  <p>&#1054;&#1089;&#1085;&#1086;&#1074;&#1072;&#1085;&#1086; &#1085;&#1072; &#1072;&#1082;&#1090;&#1077; '.iconv("utf-8","windows-1251",$r[5]).' &#1086;&#1090; '.date('d.m.Y',strtotime($r[6])).'</p>
  <p> &#1048;&#1085;&#1089;&#1087;&#1077;&#1082;&#1090;&#1086;&#1088; : '.iconv("utf-8","windows-1251",$r[7]).'</p>';
  
  }
   echo '<div id="view_'.$path.'_p">'.$p.'</div>';
   echo '<div id="view_'.$path.'_r" style="display:none"><form method="post" >'.$up.'</form></div>';
   echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';
   
?>