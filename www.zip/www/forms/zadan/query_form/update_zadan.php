<?php 
include_once("..\..\link\link.php");

$path=$_POST['path'];
echo $path;
switch ($path)
{
case 'zadan': zadan();
break;
}
function zadan(){
$id=$_POST['id'];
$d1=$_POST['d1'];
$d2=$_POST['d2'];
$d4=$_POST['d3'];

$q_text="UPDATE `tasks` SET `date_tasks`='".$d1."',`type_tasks`.`name`='".$d2."',`results_tasks`.`name`='".$d3."' WHERE`id`='".$id."'";

echo $q_text;
$q=mysql_query ($q_text);
}
?>