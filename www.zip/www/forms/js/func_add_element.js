function AddListInDoc() {
    var
    
}