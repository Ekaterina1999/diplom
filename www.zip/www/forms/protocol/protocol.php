<div id="protocol_tab" >
<script>view("protocol");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_protocol" value="&#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1099;&#1081; &#1087;&#1088;&#1086;&#1090;&#1086;&#1082;&#1086;&#1083; " onclick="f_protocol_create()"  />
</form>
<div id="tab_protocol_view"></div>
</div>
<!-- +++++++++ -->
<div id="view_protocol_div"  style="display:none">
 </div>
 <!--  -->
<div id="add_protocol_div"  style="display:none">
  <? include("create_protocol.php"); ?>
</div>
 