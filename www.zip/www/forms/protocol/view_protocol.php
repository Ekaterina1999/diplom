<? 
//добавила весь код
include_once("..\link\link.php");

$path=$_POST['path'];
$id=$_POST['id'];

$b_b= '<input  type="button" height="50" align="center" class="back_form" value="&#1053;&#1072;&#1079;&#1072;&#1076;" onclick="divindiv('."'".$path.'_tab'."'".')" />';
$b_u= '<input  type="button" height="50" align="center" class="up_form" value="&#1056;&#1077;&#1076;&#1072;&#1082;&#1090;&#1080;&#1088;&#1086;&#1074;&#1072;&#1090;&#1100;" onclick="butt_up('."'".$path."'".''.",$(this).val(),"."'".$id."'".')" />';
 
 echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';



$year=date('Y');

$text_q='SELECT `id`, `num`,  `Date_protocol`,`article`.`article` , `additionally`, `id_notify` FROM `protocol`
left join `article` on `article`.`id_article`=`protocol`.`article` WHERE `year_protocol` ="'.$year.'" and `id` ="'.$id.'" ORDER BY `num` DESC ';

  
  $q=mysql_query ($text_q)or die (Mysql_error());
  $count=mysql_num_rows($q);
  while ($r = mysql_fetch_row($q))
   {
 
   $p=$p.'<p> &#8470; '.$r[1].' &#1044;&#1072;&#1090;&#1072; '.date('d.m.Y',strtotime($r[2])).'</p>
   &#1057;&#1090;&#1072;&#1090;&#1100;&#1103; : '.iconv("utf-8","windows-1251",$r[3]).'</p>
   <p> &#1044;&#1086;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1077;&#1083;&#1100;&#1085;&#1086; : '.iconv("utf-8","windows-1251",$r[4]).'</p>';

   $up=$up.'<p>&#8470; '.$r[1].' &#1044;&#1072;&#1090;&#1072; <input type="date" class="data_up" id="d1" value="'.$r[2].'"/></p>
  <p>&#1057;&#1090;&#1072;&#1090;&#1100;&#1103; : <textarea id="d2" class="data_up"  >'.iconv("utf-8","windows-1251",$r[3]).'</textarea></p>
  <p> &#1044;&#1086;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1077;&#1083;&#1100;&#1085;&#1086; : <textarea id="d3" class="data_up"  >'.iconv("utf-8","windows-1251",$r[4]).'</textarea></p>';
  
  }
   echo '<div id="view_'.$path.'_p">'.$p.'</div>';
   echo '<div id="view_'.$path.'_r" style="display:none"><form method="post" >'.$up.'</form></div>';
   echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';
   
?>