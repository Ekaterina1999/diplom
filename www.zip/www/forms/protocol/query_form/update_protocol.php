<?php 
include_once("..\..\link\link.php");

$path=$_POST['path'];
echo $path;
switch ($path)
{
case 'pred': pred();
break;
}
function pred(){
$id=$_POST['id'];
$d1=$_POST['d1'];
$d2=$_POST['d2'];
$d4=$_POST['d3'];

$q_text="UPDATE `protocol` SET `Date_protocol`='".$d1."',`article`.`article`='".$d2."',`additionally`='".$d3."' WHERE`id`='".$id."'";

echo $q_text;
$q=mysql_query ($q_text);
}
?>


