<div id="predpis_old_tab" ><script>view("predpis_old");</script>
<form   method="get">
<input  type="button" height="50" align="center" name="cr_predpis_old" value="&#1047;&#1072;&#1085;&#1077;&#1089;&#1077;&#1085;&#1080;&#1077; &#1089;&#1090;&#1072;&#1088;&#1086;&#1075;&#1086; &#1087;&#1088;&#1077;&#1076;&#1087;&#1080;&#1089;&#1072;&#1085;&#1080;&#1103; " onclick="f_predpis_old_create()"  />
</form>
<div id="tab_predpis_old_view"></div>
</div>
<div id="add_predpis_old_div"  style="display:none">
  <? include("create_predpis_old.php"); ?>
</div>
 