<?
mysql_query('droup table obr_incoming_id'.$user_id.'_user'));
mysql_query('droup table obr_obj_id'.$user_id.'_user'));
?>