

 <!-- не нужное!!!!!!!!!!!!! -->
<!-- вообще я в report_obj.php ее добавляла <div id="rating_work" >



<form>
<h1 align="center">Otchet po podnadzornym (report_obj)</h1>
<p>Выберите отдел
<select id="sel_report">

<option value="0" selected="selected">Все</option>
<option value="1">Выездной</option>
<option value="2">Документарный</option>

</select>
</p>
<p>&nbsp;</p>
<p>С
<input name="d1" type="date" id="d1" value="<?// $d=date_create();
//echo $d->format('Y-m-d');
?>"/>
По
<input name="d2" type="date" id="d2" value="<?// $d=date_create();
//echo $d->format('Y-m-d');
?>"/>
</p>
<p>
<input type="button" name="start_r" id="start_r" value="Сформировать отчет" onclick="start_report_all('report_obj')" />

<input type="button" align="right" name="ex" id="ex" value=" Экспорт" onclick="Excel()" disabled="disabled" />
<input type="button" align="right" name="msw" id="msw" value=" Экспорт" onclick="exportHTML()" disabled="disabled" />
</p>
</form>
<div id="result_r" name="result_r" style="display:block"></div>
</div>
 
метка это result_r -->






