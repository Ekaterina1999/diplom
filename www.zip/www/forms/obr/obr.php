<div id="obr_tab" >
<script>view_obr();</script>
<form method="post">
<input  type="button" height="50" align="center" name="cr_obr" value="&#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1086;&#1077; &#1086;&#1073;&#1088;&#1072;&#1097;&#1077;&#1085;&#1080;&#1077; 
 " onclick="f_obr_create()" />
</form>

<div id="tab_obr_view"></div>
</div>


<div id="view_obr_div"  style="display:none">
 </div>
<input type="button" align="right" name="msw" id="msw" value="&#1069;&#1082;&#1089;&#1087;&#1086;&#1088;&#1090; Word" onclick="exportHTML()"/>
 
<div id="add_obr_div"  style="display:none">
  <? include("create_obr2.php"); ?>
</div>
<!-- ++++++++++++ -->
<div id="exportHTML" >
</div>
<!--  -->