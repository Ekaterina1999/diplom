<? 
include_once("..\link\link.php"); //подключение бд
 
$path=$_POST['path'];
$id=$_POST['id']; //получение id
//кнопка назад
$b_b= '<input  type="button" height="50" align="center" class="back_form" value="&#1053;&#1072;&#1079;&#1072;&#1076;" onclick="divindiv('."'".$path.'_tab'."'".')" />';
//кнопка редактировать
$b_u= '<input  type="button" height="50" align="center" class="up_form" value="&#1056;&#1077;&#1076;&#1072;&#1082;&#1090;&#1080;&#1088;&#1086;&#1074;&#1072;&#1090;&#1100;" onclick="butt_up('."'".$path."'".''.",$(this).val()".')" />';
//кнопка выгрузка в Word	
// $b_w= '<input type="button" align="right" name="msw" id="msw" value="&#1069;&#1082;&#1089;&#1087;&#1086;&#1088;&#1090; Word" onclick="'exportHTML()'"/>';
// '<div id="result_r" name="result_r" style="display:block"></div>';

// непонятно!!!!!! возможно id чего-то
echo '<div id="view_'.$path.'_p">';
//размещение на форме кнопок назад и редактировать 
 //echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';
// надпись Обращение основано на следующих входящих
 echo '<p>&#1054;&#1073;&#1088;&#1072;&#1097;&#1077;&#1085;&#1080;&#1077; &#1086;&#1089;&#1085;&#1086;&#1074;&#1072;&#1085;&#1086; &#1085;&#1072; &#1089;&#1083;&#1077;&#1076;&#1091;&#1102;&#1097;&#1080;&#1093; &#1074;&#1093;&#1086;&#1076;&#1103;&#1097;&#1080;&#1093; :</p>';
 //вывод результата функции
 echo incom($id);
 //надпись Объект проверки
 echo '<p>&#1054;&#1073;&#1098;&#1077;&#1082;&#1090; &#1087;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1080;: </p>';
 // вывод  id объекта
 echo obj($id);

echo '</div>';
//не понятно !!!
  echo '<div id="view_'.$path.'_r" style="display:none"></div>';
  //размещение на форме кнопок назад и редактировать 
 echo '<form method="post" align="center">'.$b_b.' '.$b_u.''.$b_w.'</form>';
 //функция, которая на входе принимает id обращения и по этопу id находит документы. Возвращает Номер и дата входящего
 function incom($id_obr){
$text_q='SELECT distinct num_incoming, incoming_date, incoming.id
FROM  link_complaints
 JOIN complaints ON link_complaints.id_complaints = complaints.Id
 JOIN incoming ON link_complaints.id_incoming_c = incoming.id
  JOIN link_complaints_obj ON link_complaints_obj.id_complaints = complaints.Id 
 JOIN link_complaints_address ON link_complaints_obj.id = link_complaints_address.id_link_complaints_obj
  JOIN link_complaints_violation ON link_complaints_address.id = link_complaints_violation.id_address_link where complaints.id ="'.$id_obr.'"';
// переменнтая хранит результат запроса
$q_obj=mysql_query ($text_q)or die (Mysql_error());
//обрабатывает один ряд результата, на который ссылается переданный указатель. Ряд возвращается в массиве. 
//Каждая колонка распологается в следующей ячейке массива. Массив начинается с индекса 0.
while ($r_obj = mysql_fetch_row($q_obj))
 {
 //не понятно!!!!!!!!!
$incom=$incom.'<p>'.iconv("utf-8","windows-1251",$r_obj[0]).' &#1086;&#1090;: '.date('d.m.Y',strtotime($r_obj[1])).'<input style="display:none"  type="button" height="50" align="center" class="del_b" value="X" onclick="del_date('."'1'".''."'".$r_obj[2]."'".')" /></p>';
 
}
//возвращает массив
return $incom;
}
// конец функции
// функция, которая возвращает объект проверки
function obj($id_obr){
 $text_q='SELECT distinct Name_org,license, complaints_obj.id
FROM  link_complaints 

 JOIN complaints ON link_complaints.id_complaints = complaints.Id

 JOIN incoming ON link_complaints.id_incoming_c = incoming.id

  JOIN link_complaints_obj ON link_complaints_obj.id_complaints = complaints.Id 

  JOIN complaints_obj ON complaints_obj.id= link_complaints_obj.id_obj_c
 JOIN link_complaints_address ON link_complaints_obj.id = link_complaints_address.id_link_complaints_obj

  JOIN link_complaints_violation ON link_complaints_address.id = link_complaints_violation.id_address_link  WHERE complaints.id="'.$id_obr.'"';
 
	  		$q_obj1=mysql_query ($text_q)or die (Mysql_error());
				while ($r_obj1 = mysql_fetch_row($q_obj1))
				{
						if($r_obj1[1]==1){$lic='<input disabled type="checkbox"  checked />';}
						else {$lic='<input disabled type="checkbox" />';}
						//хранит данные массива
						$obj=$obj.'<p onclick="open_obj('."'".$r_obj1[2]."'".')">'.$lic.iconv("utf-8","windows-1251",$r_obj1[0]).'<input style="display:none"  type="button" height="50" align="center" class="del_b" value="X" onclick="del_date('."'2'".''."'".$r_obj1[2]."'".')" /></p><div id="open_obj_'.$r_obj1[2].'" style="display:none">'.adr($id_obr,$r_obj1[2]).'</div>';
				}
return $obj;
}
//конец функции
//функция возвраает адрес (место проведения)
function adr($id,$obj){
global $count_rec;
 $text_q='SELECT distinct city_zab.name ,  street_zab.name , address.house,  address.housing ,  address.flat, id_address
FROM  link_complaints 

 JOIN complaints ON link_complaints.id_complaints = complaints.Id

 JOIN incoming ON link_complaints.id_incoming_c = incoming.id

  JOIN link_complaints_obj ON link_complaints_obj.id_complaints = complaints.Id 

 JOIN link_complaints_address ON link_complaints_obj.id = link_complaints_address.id_link_complaints_obj

 
 JOIN  address ON  address.id = id_address
 JOIN  city_zab ON  address.id_city =  city_zab.id 
 JOIN  street_zab ON  address.id_street =  street_zab.id 


  JOIN link_complaints_violation ON link_complaints_address.id = link_complaints_violation.id_address_link  
  WHERE  complaints.id="'.$id.'" and link_complaints_obj.id_obj_c="'.$obj.'"';
 $count_rec=0;
	  		$q_obj1=mysql_query ($text_q)or die (Mysql_error());
				while ($r_obj1 = mysql_fetch_row($q_obj1))
				{
					//увеличивает на 1
				$ii++;
		
				if(($r_obj1[3]=="")or($r_obj1[3]=="0")){$housing="";}else{$housing=', '.iconv("utf-8","windows-1251",$r_obj1[3]);}
				if(($r_obj1[4]=="")or($r_obj1[4]=="0")){$flat="";}else{$flat=', '.$r_obj1[4];}
				
$address=$address.'<tr><td>'.iconv("utf-8","windows-1251",$r_obj1[0]).', '.iconv("utf-8","windows-1251",$r_obj1[1]).', '.$r_obj1[2].$housing.$flat.'</td><td>'.v($id,$r_obj1[5]).'</td></tr>';
				
				}
		$address='<table border="2" ><tr><td>&#1040;&#1076;&#1088;&#1077;&#1089;</td>
<td>&#1053;&#1072;&#1088;&#1091;&#1096;&#1077;&#1085;&#1080;&#1077; </td></tr>'.$address.'</table>';
return  $address;
}
//конец функции


function v($id_obr,$adr){//,$id_address){
 $text_q='SELECT distinct violation.NAME_CODE ,  type_violation.Name_type 
FROM  link_complaints 

 JOIN complaints ON link_complaints.id_complaints = complaints.Id

 JOIN incoming ON link_complaints.id_incoming_c = incoming.id

  JOIN link_complaints_obj ON link_complaints_obj.id_complaints = complaints.Id 

 JOIN link_complaints_address ON link_complaints_obj.id = link_complaints_address.id_link_complaints_obj

 
  JOIN link_complaints_violation ON link_complaints_address.id = link_complaints_violation.id_address_link 

JOIN  violation ON violation.ID_violation =link_complaints_violation.ID_violation 

JOIN  type_violation
					ON  violation.ID_TYPE_VIOLATION =type_violation.Id_type_violation 


 WHERE complaints.id="'.$id_obr.'" AND id_address="'.$adr.'"';
 
	  		$q_obj1=mysql_query ($text_q)or die (Mysql_error());
				while ($r_obj1 = mysql_fetch_row($q_obj1))
				{
				
		
			
$v=$v.'<p>'.iconv("utf-8","windows-1251",$r_obj1[1]).' - '.iconv("utf-8","windows-1251",$r_obj1[0]).'</p>';
		
			}
return $v;
}

 ?>
