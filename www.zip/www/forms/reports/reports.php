 <div id="157r"  style="border:solid; display:none" onclick="clickDiv('form_157r')"><p>&#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;&#1100;&#1085;&#1099;&#1081; &#1086;&#1090;&#1095;&#1077;&#1090; 157-&#1088;" </p>
</div>
<div id="form_157r" style="display:none" >
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>

<form id="form1" name="form1" method="post" action="">
  <p>
    <select id="period_report_157r">
	<option value="0"></option>
        <option value="1">I &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;</option>
  <option value="2">II &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="3">III &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="4">IV &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;    </option>
    </select>
    <input type="number" id="year_report_157r" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('157r')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>
<div id="param_157r"  style="display:none">
</div>
</div>

 <div id="1k" style="border:solid"   onclick="clickDiv('form_1k')"> <p>1-&#1050;</p></div>

 <div id="form_1k" style="display:none">
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>
<form id="form2" name="form2" method="post" action="">
  <p>
    <select id="period_report_1k">
	<option value="0"></option>
        <option value="1">I &#1087;&#1086;&#1083;&#1091;&#1075;&#1086;&#1076;&#1080;&#1077;</option>
  <option value="2">&#1043;&#1086;&#1076;</option>
    </select>
    <input type="number" id="year_report_1k" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('1k')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>
<div id="param_1k"  style="display:block">
</div></div>
<div id="1l" style="border:solid"  onclick="clickDiv('form_1l')"><p>1-&#1051;</p></div>
<div id="form_1l" style="display:none; ">
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>
<form id="form3" name="form3" method="post" action="">
  <p>
    <select id="period_report_1l">
	<option value="0"></option>
        <option value="1">I &#1087;&#1086;&#1083;&#1091;&#1075;&#1086;&#1076;&#1080;&#1077;</option>
  <option value="2">&#1043;&#1086;&#1076;</option>
    </select>
    <input type="number" id="year_report_1l" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('1l')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>

<div id="param_1l"  style="display:block"></div></div>
<div id="1gmu" style="border:solid;display:none"  onclick="clickDiv('form_1gmu')"><p>1-&#1043;&#1052;&#1059;</p></div>
<div id="form_1gmu" style="display:none">
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>
<form id="form4" name="form4" method="post" action="">
  <p>
    <select id="period_report_1gmu">
	<option value="0"></option>
             <option value="1">I &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;</option>
  <option value="2">II &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="3">III &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="4">&#1043;&#1086;&#1076;</option>
    </select>
    <input type="number" id="year_report_1gmu" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('1gmu')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>
<div id="param_1gmu"  style="display:block"></div></div>
<div id="minstoy" style="border:solid; display:none"  onclick="clickDiv('form_minstroy')"><p>&#1052;&#1080;&#1085;&#1089;&#1090;&#1088;&#1086;&#1081;</p></div>
<div id="form_minstroy" style="display:none">
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>
<form id="form5" name="form5" method="post" action="">
  <p>
    <select id="period_report_minstoy">
	<option value="0"></option>
              <option value="1">I &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;</option>
  <option value="2">II &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="3">III &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="4">&#1043;&#1086;&#1076;</option>
    </select>
    <input type="number" id="year_report_minstoy" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('minstoy')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>
<div id="param_minstoy"  style="display:block"></div></div>
<div id="universal" style="border:solid; display:none"  onclick="clickDiv('form_universal')">
  <p>&#1059;&#1085;&#1080;&#1074;&#1077;&#1088;&#1089;&#1072;&#1083;&#1100;&#1085;&#1099;&#1081;</p>
</div>
<div id="form_1l" style="display:none">
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>
<form id="form6" name="form6" method="post" action="">
  <p>

    <input type="number" id="year_report_universal" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('universal')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>
<div id="param_universal"  style="display:block"></div></div>
<div id="pred_r"  style="border:solid;" onclick="clickDiv('form_pred_r')">
  <p>&#1053;&#1077;&#1080;&#1089;&#1087;&#1086;&#1083;&#1085;&#1077;&#1085;&#1099;&#1077; &#1087;&#1088;&#1077;&#1076;&#1087;&#1080;&#1089;&#1072;&#1085;&#1080;&#1103; &#1079;&#1072;&#1082;&#1088;&#1077;&#1087;&#1083;&#1077;&#1085;&#1085;&#1099;&#1077; &#1079;&#1072; &#1089;&#1086;&#1090;&#1088;&#1091;&#1076;&#1085;&#1080;&#1082;&#1072;&#1084;&#1080; </p>
</div>
<div id="form_pred_r" style="display:none" >
<p>&#1042;&#1099;&#1073;&#1077;&#1088;&#1080;&#1090;&#1077; &#1087;&#1077;&#1088;&#1080;&#1086;&#1076; </p>

<form id="form1" name="form1" method="post" action="">
  <p>
    <select id="period_report_pred_r">
	<option value="0"></option>
        <option value="1">I &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;</option>
  <option value="2">II &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="3">III &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083; </option>
  <option value="4">IV &#1050;&#1074;&#1072;&#1088;&#1090;&#1072;&#1083;    </option>
    </select>
    <input type="number" id="year_report_pred_r" value="<? $year=date('Y'); echo $year; ?>"  width="25" maxlength="4"/>
	<input type="button" onclick="result_report('pred_r')" value="&#1042;&#1099;&#1087;&#1086;&#1083;&#1085;&#1080;&#1090;&#1100;"/>
</p>

</form>
<div id="param_pred_r"  style="display:none">
</div>
</div>
