<? 
//добавила весь код
include_once("..\link\link.php");

$path=$_POST['path'];
$id=$_POST['id'];

$b_b= '<input  type="button" height="50" align="center" class="back_form" value="&#1053;&#1072;&#1079;&#1072;&#1076;" onclick="divindiv('."'".$path.'_tab'."'".')" />';
$b_u= '<input  type="button" height="50" align="center" class="up_form" value="&#1056;&#1077;&#1076;&#1072;&#1082;&#1090;&#1080;&#1088;&#1086;&#1074;&#1072;&#1090;&#1100;" onclick="butt_up('."'".$path."'".''.",$(this).val(),"."'".$id."'".')" />';
 
 echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';



$year=date('Y');

$text_q='SELECT   `notify`.`id` ,  `notify`.`num` ,  `date_notify` , `date_notify1`, `time_notify`  
FROM  `notify`
  where  `year_notify` ="'.$year.'" and `notify`.`id` ="'.$id.'" ORDER BY `notify`.`num` DESC ';
  
  $q=mysql_query ($text_q)or die (Mysql_error());
  $count=mysql_num_rows($q);
  while ($r = mysql_fetch_row($q))
   {
 
   $p=$p.'<p>  &#8470; '.$r[1].' &#1086;&#1090; '.date('d.m.Y',strtotime($r[2])).'</p>
   <p> &#1052;&#1077;&#1088;&#1086;&#1087;&#1088;&#1080;&#1103;&#1090;&#1080;&#1077; &#1079;&#1072;&#1087;&#1083;&#1072;&#1085;&#1080;&#1088;&#1086;&#1074;&#1072;&#1085;&#1086; &#1085;&#1072;: '.date('d.m.Y',strtotime($r[3])).'  '.date('d.m.Y',strtotime($r[5])).'</p>';
  }
   echo '<div id="view_'.$path.'_p">'.$p.'</div>';
   echo '<form method="post" align="center">'.$b_b.' '.$b_u.'</form>';
   
?>
